package lesson4.lecture.staticinherit.fifth;

public class Super extends SuperSuper {
	
//	static void tryit() {
//		System.out.println("super");
//	}
}
