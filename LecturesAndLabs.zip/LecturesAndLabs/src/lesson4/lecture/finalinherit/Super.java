package lesson4.lecture.finalinherit;

public class Super {
	final void print() {
		System.out.println("hello");
	}	
}
