package lesson3.lecture.inheritance4;

public class ClassB {
	private String name;
	public void setName(String name) {
		this.name = name;
	}
	
	/* Unknown to subclasses */
	public void newMethod(String suffix) {
		name += suffix;
	}
	 
}
