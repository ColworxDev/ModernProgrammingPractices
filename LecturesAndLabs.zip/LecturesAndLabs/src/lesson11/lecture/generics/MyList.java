package lesson11.lecture.generics;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class MyList extends ArrayList<String >{

}

@SuppressWarnings("serial")
class MyList2<T> extends ArrayList<T>{
	
}
