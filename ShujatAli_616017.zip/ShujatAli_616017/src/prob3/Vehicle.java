package prob3;

//implement
public abstract class Vehicle {
	public abstract int getMilesUsedToday();
}
