package lesson4.lecture.staticinherit.second;

public class Super {
	static void print() {
		System.out.println("hello");
	}	
}
