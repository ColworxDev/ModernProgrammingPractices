package lesson4.lecture.staticinherit.first;

//Shows that static method are inherited
public class Sub extends Super {
	public static void main(String[] args) {
		Sub.print();   	
	}	
}
