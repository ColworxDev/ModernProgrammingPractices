package prob1;

import java.util.List;

public class ListsEqual {
	public boolean listsAreEqual(List<Integer> list1, List<Integer> list2) {
		//implement recursively
		if ((list1 == null && list2 != null) || (list1 != null && list2 == null)) {
			return false;
		}
		
		if ((list1 == null && list2 == null) || 
				(list1.isEmpty() && list2.isEmpty())) {
			return true;
		}
		
		if (list1.size() != list2.size()) {
			return false;
		}
		
		if (list1.size() == 1 ) {
			return list1.get(0) == list2.get(0);
		} else {
			int n1 = list1.remove(0);
			int n2 = list2.remove(0);
			if (n1 == n2) {
				return listsAreEqual(list1, list2);
			} else {
				return false;
			}
		}	
	}
}
