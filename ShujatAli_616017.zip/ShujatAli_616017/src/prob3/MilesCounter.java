package prob3;

import java.util.ArrayList;
import java.util.List;

public class MilesCounter {
	public static List<Vehicle> convertArray(Object[] vehicleArray) {
		/* implement */
		List<Vehicle> report = new ArrayList();
		for(Object item: vehicleArray) {
			report.add((Vehicle)item);
		}
		return report;
	}
	
	
	public static int computeTotalMiles(List<Vehicle> vehicleList) {
		/*implement */
		int sum = 0;
		for(Vehicle item: vehicleList) {
			sum += item.getMilesUsedToday();
		}
		return sum;
	}
}
