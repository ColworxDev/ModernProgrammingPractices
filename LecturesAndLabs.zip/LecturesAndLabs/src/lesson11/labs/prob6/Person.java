package lesson11.labs.prob6;

public class Person {
	String name;
	public Person(String n) {
		name = n;
	}
	public String getName() {
		return name;
	}
}
