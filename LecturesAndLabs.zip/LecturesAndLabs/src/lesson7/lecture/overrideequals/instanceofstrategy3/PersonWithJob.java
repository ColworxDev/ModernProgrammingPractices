package lesson7.lecture.overrideequals.instanceofstrategy3;

public class PersonWithJob extends Person {
	private double salary;
	PersonWithJob(String n, double s) {
		super(n);
		salary = s;
	}
}
