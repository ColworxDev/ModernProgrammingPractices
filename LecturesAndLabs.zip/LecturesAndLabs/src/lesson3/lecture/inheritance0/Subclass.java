package lesson3.lecture.inheritance0;



public class Subclass extends Superclass {
	public static void main(String[] args) {
		Subclass sub = new Subclass();
		sub.print("hello");

	}
}
