package lesson7.lecture.hashcode.bad1;

public class Pair {
	String first;
	String second;
	public Pair(String f, String s) {
		first = f;
		second = s;
	}
	
	

}
