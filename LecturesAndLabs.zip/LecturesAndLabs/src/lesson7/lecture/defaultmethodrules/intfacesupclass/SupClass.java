package lesson7.lecture.defaultmethodrules.intfacesupclass;

public class SupClass {
	public void myMethod(int x) {
		System.out.println(x + 1);
	}
}
