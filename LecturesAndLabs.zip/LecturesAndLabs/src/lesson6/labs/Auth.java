package lesson6.labs;

import java.io.Serializable;

public enum Auth implements Serializable {
	MEMBER, SELLER, BOTH;
}
